const express = require('express');
const rouuter = express.Router();
const Habito = require('..//models/Habito');

// Rota para listar os hábitos
app.get('/habitos', async (req, res) => {
  try {
    const habitos = await Habito.find();
    res.json(habitos);
  } catch (err) {
    res.status(500).json({ mensagem: 'Erro ao buscar hábitos', erro: err });
  }
});

//  criar hábito
Router.post('/', async (req, res) => {
    try{
        const novoHabito = new Habito(req.body);
        await novoHabito.save();
        res.status(201).json(novoHabito);
    } catch (err) {
        res.status(400).json({ erro: "Erro ao criar hábito", detalhes: err});
    }
});

//  buscar por ID
Router.get("/:id", async (req, res) => {
    try {
        const habito = await Habito.findById(req.params.id);
        if(!habito) return res.status(404).json({ erro: "Hábito não encontrado"});
        res.json(habito);
    } catch (err) {
        res.status(500).json({ erro: "Erro ao buscar hábito"});
    }
});


//  atualizar hábito
express.Router.put("/:id", async (req, res) => {
    try {
        const atualizado = await Habito.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if(!atualizado) return res.status(404).json({ erro: "Hábito não encontrado", detalhes: err});
        res.json(atualizado);
    } catch (err) {
        ress.status(400).json({ erro: "Erro ao atualizar hábito", detalhes: err});
    }
});

//  Deletar hábito
router.delete('/:id', async (req, res) => {
  try {
    const deletado = await Habito.findByIdAndDelete(req.params.id);
    if (!deletado) return res.status(404).json({ erro: 'Hábito não encontrado' });
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao deletar hábito' });
  }
});

module.exports = router;